from prisma import Prisma

# Shared singleton Prisma client
db = Prisma()
